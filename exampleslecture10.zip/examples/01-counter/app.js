"use strict";
// defer guarantees that these HTML elements have already been parsed.
const scoreOutput = document.querySelector("#score");
const addButton = document.querySelector("#add");
const removeButton = document.querySelector("#remove");
const resetButton = document.querySelector("#reset");
let score = 0;

function render() {
  scoreOutput.textContent = String(score);
  removeButton.disabled = score === 0;
}
function addPoint() {
  score += 1;
  render();
}
function removePoint() {
  if (score === 0) return;
  score -= 1;
  render();
}
function reset() {
  score = 0;
  render();
}
// Register once. render does not attach listeners.
addButton.addEventListener("click", addPoint);
removeButton.addEventListener("click", removePoint);
resetButton.addEventListener("click", reset);
render();
