# Document readiness laboratory

Open index.html in a browser. Open study.html for the reading order, behaviour checks, extension, hint, solution explanation and complete source. No installation, server or internet connection is needed.

Previous knowledge: HTML document order, script elements, functions and conditions.

New ideas: Parsing order, defer, DOMContentLoaded, readyState and script placement.
