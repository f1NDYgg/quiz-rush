"use strict";
function init() {
  const button = document.querySelector("#action");
  const output = document.querySelector("#count");
  let count = 0;
  document.querySelector("#observation").textContent = "The query found the button. Initialisation ran once.";
  button.addEventListener("click", function () {
    count += 1;
    output.textContent = String(count);
  });
}
if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", init, { once: true });
} else {
  init();
}
