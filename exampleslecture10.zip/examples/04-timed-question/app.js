"use strict";
const answers = document.querySelector("#answers");
const buttons = document.querySelectorAll(".answer");
const submitButton = document.querySelector("#submit");
const result = document.querySelector("#result");
const colourInput = document.querySelector("#colour");
let selectedIndex = null; // null is no answer. 0 is the first answer.
let submitted = false;
let timerId = null;
let deadline = 0;
function render() {
  // One state value controls all the selection cues.
  answers.style.setProperty("--player-colour", colourInput.value);
  buttons.forEach(function (button, index) {
    const chosen = index === selectedIndex;
    button.classList.toggle("selected", chosen);
    button.setAttribute("aria-pressed", String(chosen));
    button.querySelector(".marker").textContent = chosen ? "Selected" : "";
    button.disabled = submitted;
  });
  submitButton.disabled = selectedIndex === null || submitted;
  colourInput.disabled = submitted;
}
function selectAnswer(index) {
  if (submitted) return;
  if (Date.now() >= deadline) { finish("timeout"); return; }
  selectedIndex = index;
  render();
}
function finish(reason = "manual") {
  if (submitted) return;

  submitted = true; // Close before scoring, regardless of caller.
  stopTimer();
  document.querySelector("#time").textContent = String(secondsLeft());
  const points = selectedIndex === 0 ? 10 : 0;
  const answer = selectedIndex === null ? "No answer" : buttons[selectedIndex].firstElementChild.textContent;
  result.textContent = `${reason === "timeout" ? "Time ended. " : ""}${answer}. ${points} points. Correct answer: <p>.`;
  render();
}
function restart() {
  stopTimer();
  selectedIndex = null;
  submitted = false;
  result.textContent = "";
  deadline = Date.now() + 15000;
  render();
  timerId = setInterval(tick, 200);
  tick();
  buttons[0].focus();
}
buttons.forEach(function (button, index) {
  button.addEventListener("click", function () { selectAnswer(index); });
});
submitButton.addEventListener("click", function () {
  if (Date.now() >= deadline) { finish("timeout"); return; }
  if (selectedIndex === null) return;
  finish("manual");
});
colourInput.addEventListener("input", render);
document.querySelector("#restart").addEventListener("click", restart);
function stopTimer() {
  clearInterval(timerId);
  timerId = null;
}
function secondsLeft() {
  return Math.max(0, Math.ceil((deadline - Date.now()) / 1000));
}
function tick() {
  document.querySelector("#time").textContent = String(secondsLeft());
  if (Date.now() >= deadline) finish("timeout");
}
restart();
