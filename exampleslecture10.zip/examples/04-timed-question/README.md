# One timed question

Open index.html in a browser. Open study.html for the reading order, behaviour checks, extension, hint, solution explanation and complete source. No installation, server or internet connection is needed.

Previous knowledge: Every selection and rendering rule from example 03.

New ideas: A deadline, one interval handle, shared finalisation, timeout and late-click guards.
