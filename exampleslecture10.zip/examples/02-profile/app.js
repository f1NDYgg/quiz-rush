"use strict";
const form = document.querySelector("#setup");
const nameInput = document.querySelector("#name");
const roundsInput = document.querySelector("#rounds");
const colourInput = document.querySelector("#colour");
const feedback = document.querySelector("#feedback");
const preview = document.querySelector("#preview");
const previewName = document.querySelector("#preview-name");
const previewRounds = document.querySelector("#preview-rounds");

form.addEventListener("submit", function (event) {
  event.preventDefault();
  const name = nameInput.value.trim();
  const rawRounds = roundsInput.value.trim();
  const rounds = Number(rawRounds);
  if (name.length < 1 || name.length > 30) {
    feedback.textContent = "Enter a player name of 1–30 characters.";
    nameInput.focus();
    return;
  }
  if (rawRounds === "" || !Number.isInteger(rounds) || rounds < 1 || rounds > 5) {
    feedback.textContent = "Enter a whole round count from 1 to 5.";
    roundsInput.focus();
    return;
  }
  previewName.textContent = name;
  previewRounds.textContent = `${rounds} round${rounds === 1 ? "" : "s"}`;
  preview.style.setProperty("--player-colour", colourInput.value);
  preview.hidden = false;
  feedback.textContent = "Player setup accepted.";
});
function resetPreview() {
  preview.hidden = true;
  previewName.textContent = "";
  previewRounds.textContent = "";
  feedback.textContent = "";
}
document.querySelector("#reset-form").addEventListener("click", function () {
  form.reset();
  resetPreview();
  nameInput.focus();
});
resetPreview();
