const screenOne = document.querySelector('#screen1');
const screenTwo = document.querySelector('#screen2');
const buttonNext = document.querySelector('#btn-next');
const buttonPrev = document.querySelector('#btn-prev');

screenTwo.hidden = true;

function goNext() {
    let nameInput = document.querySelector('#nameInput').value;
    console.log(nameInput.trim());
    let errorMessage = document.querySelector('#errorNext');
    if (nameInput == '') {
        return;

    } else {
        screenTwo.hidden = false;
        screenOne.hidden = true;
    }
}

function goBack(){
    screenTwo.hidden = true;
        screenOne.hidden = false;
}

buttonNext.addEventListener("click", goNext);
buttonPrev.addEventListener("click", goBack);