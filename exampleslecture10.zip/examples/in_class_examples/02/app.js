const buttons = document.querySelectorAll(".answer");
let submitButton = document.querySelector('#submitButton');

submitButton.disabled = true;

function selectAnswer(index) {

    selectedIndex = index;
    render();
}

function render() {
    buttons.forEach(function (button, index) {
        const chosen = index === selectedIndex;
        button.disabled = false;
        if (chosen) {
            button.disabled = submitButton;
        } 
    });
    document.querySelector('#submitButton').disabled = false;
}

buttons.forEach(function (button, index) {
    button.addEventListener("click", function () { selectAnswer(index); });
});

