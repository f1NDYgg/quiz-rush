let timerId;
let isSubmit = false;

const submitButton = document.querySelector('#submit');

start();

function start() {
    if (isSubmit) {
        return;
    }

    let timer = 15;

    tick(timer);

    timerId = setInterval(() => {
        timer--;
        tick(timer);
    }, 1000);
}

function tick(timer) {
    if (isSubmit) {
        clearInterval(timerId);
        return;
    }

    document.querySelector("#time").textContent = String(timer);

    if (timer <= 0) {
        clearInterval(timerId);
        stopSubmit();
    }
}

submitButton.addEventListener('click', () => {
    isSubmit = true;
    submitButton.disabled = true;
    clearInterval(timerId);
});

function stopSubmit() {
    console.log("Time is up!");
    submitButton.disabled = true;
}