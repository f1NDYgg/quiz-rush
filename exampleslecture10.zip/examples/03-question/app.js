"use strict";
const answers = document.querySelector("#answers");
const buttons = document.querySelectorAll(".answer");
const submitButton = document.querySelector("#submit");
const result = document.querySelector("#result");
const colourInput = document.querySelector("#colour");
let selectedIndex = null; // null is no answer. 0 is the first answer.
let submitted = false;

function render() {
  // One state value controls all the selection cues.
  answers.style.setProperty("--player-colour", colourInput.value);
  buttons.forEach(function (button, index) {
    const chosen = index === selectedIndex;
    button.classList.toggle("selected", chosen);
    button.setAttribute("aria-pressed", String(chosen));
    button.querySelector(".marker").textContent = chosen ? "Selected" : "";
    button.disabled = submitted;
  });
  submitButton.disabled = selectedIndex === null || submitted;
  colourInput.disabled = submitted;
}
function selectAnswer(index) {
  if (submitted) return;

  selectedIndex = index;
  render();
}
function finish(reason = "manual") {
  if (submitted) return;
  if (selectedIndex === null) return;
  submitted = true; // Close before scoring, regardless of caller.

  const points = selectedIndex === 0 ? 10 : 0;
  const answer = selectedIndex === null ? "No answer" : buttons[selectedIndex].firstElementChild.textContent;
  result.textContent = `${reason === "timeout" ? "Time ended. " : ""}${answer}. ${points} points. Correct answer: <p>.`;
  render();
}
function restart() {

  selectedIndex = null;
  submitted = false;
  result.textContent = "";

  render();

  buttons[0].focus();
}
buttons.forEach(function (button, index) {
  button.addEventListener("click", function () { selectAnswer(index); });
});
submitButton.addEventListener("click", function () {

  if (selectedIndex === null) return;
  finish("manual");
});
colourInput.addEventListener("input", render);
document.querySelector("#restart").addEventListener("click", restart);

restart();
