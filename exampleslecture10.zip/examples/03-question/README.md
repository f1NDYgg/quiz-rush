# One untimed question

Open index.html in a browser. Open study.html for the reading order, behaviour checks, extension, hint, solution explanation and complete source. No installation, server or internet connection is needed.

Previous knowledge: Buttons, classes, CSS custom properties, functions, booleans and strict comparison.

New ideas: NodeList.forEach, explicit null selection, complete selected appearance and one-time submission.
