"use strict";
const setupForm = document.querySelector("#setup-form");
const setupFeedback = document.querySelector("#setup-feedback");
const optionsBox = document.querySelector("#options");
const submitButton = document.querySelector("#submit");
const nextButton = document.querySelector("#next");
const result = document.querySelector("#turn-result");
const timeOutput = document.querySelector("#time");
let game = null;
// These resources do not belong in JSON game data.
let timerId = null;
let deadline = 0;

function validQuestion(q) {
  return q !== null && typeof q === "object" &&
    typeof q.id === "string" && q.id.trim() !== "" &&
    ["HTML", "CSS", "JS"].includes(q.subject) &&
    typeof q.prompt === "string" && q.prompt.trim() !== "" &&
    Array.isArray(q.options) && q.options.length === 4 &&
    q.options.every(option => typeof option === "string" && option.trim() !== "") &&
    Number.isInteger(q.correctIndex) && q.correctIndex >= 0 && q.correctIndex < q.options.length;
}
function stopTimer() {
  clearInterval(timerId);
  timerId = null;
}
function showScreen(id, headingId) {
  document.querySelectorAll(".screen").forEach(function (screen) {
    screen.hidden = screen.id !== id;
  });
  document.querySelector(`#${headingId}`).focus();
}
function currentPlayer() { return game.players[game.turnIndex % game.players.length]; }
function currentQuestion() { return game.questionQueue[game.turnIndex]; }
function updateAvailability() {
  const subject = document.querySelector("#subject").value;
  const available = QUESTIONS.filter(q => subject === "Mixed" || q.subject === subject).length;
  document.querySelector("#available").textContent = `${available} questions available. One distinct question is used per turn.`;
}
function startGame(event) {
  event.preventDefault();
  const nameInput = document.querySelector("#names");
  // split creates entries at line breaks; trim and filter remove blank lines.
  const names = nameInput.value.split("\n").map(name => name.trim()).filter(name => name !== "");
  const rawCount = document.querySelector("#count").value.trim();
  const count = Number(rawCount);
  const subject = document.querySelector("#subject").value;
  const seconds = Number(document.querySelector("#duration").value);
  if (names.length < 1 || names.length > 4 || names.some(name => name.length > 30)) {
    setupFeedback.textContent = "Enter 1–4 names, one per line, with up to 30 characters each.";
    nameInput.focus();
    return;
  }
  for (let i = 0; i < names.length; i += 1) {
    for (let j = i + 1; j < names.length; j += 1) {
      if (names[i].toLowerCase() === names[j].toLowerCase()) {
        setupFeedback.textContent = "Use distinct names for this demo.";
        nameInput.focus();
        return;
      }
    }
  }
  if (rawCount === "" || !Number.isInteger(count) || count < 1 || count > 3) {
    setupFeedback.textContent = "Use 1–3 whole questions per player.";
    document.querySelector("#count").focus();
    return;
  }
  if (!["Mixed", "HTML", "CSS", "JS"].includes(subject) || ![15, 30].includes(seconds)) {
    setupFeedback.textContent = "Choose a supported subject and duration.";
    return;
  }
  if (!QUESTIONS.every(validQuestion) || QUESTIONS.length === 0) {
    setupFeedback.textContent = "The question bank contains invalid records.";
    return;
  }
  const ids = QUESTIONS.map(q => q.id);
  if (ids.some((id, index) => ids.indexOf(id) !== index)) {
    setupFeedback.textContent = "Question IDs must be unique.";
    return;
  }
  const pool = QUESTIONS.filter(q => subject === "Mixed" || q.subject === subject);
  const totalTurns = names.length * count;
  if (pool.length < totalTurns) {
    setupFeedback.textContent = `Need ${totalTurns} distinct questions, but ${subject} has ${pool.length}. Choose fewer turns or Mixed.`;
    return;
  }
  stopTimer();
  const colours = ["#176a63", "#7b367c", "#1d5592", "#8a4a0a"];
  game = {
    subject, questionsPerPlayer: count, secondsPerQuestion: seconds,
    players: names.map((name, index) => ({ id: `p${index + 1}`, name, score: 0, colour: colours[index] })),
    questionQueue: pool.slice(0, totalTurns), // Deliberately deterministic, not shuffled.
    turnIndex: 0, selectedIndex: null, submitted: false, phase: "question", history: []
  };
  setupFeedback.textContent = "";
  showTurn();
}
function renderSelection() {
  optionsBox.style.setProperty("--player-colour", currentPlayer().colour);
  optionsBox.querySelectorAll("button").forEach(function (button, index) {
    const chosen = index === game.selectedIndex;
    button.classList.toggle("selected", chosen);
    button.setAttribute("aria-pressed", String(chosen));
    button.querySelector(".marker").textContent = chosen ? "Selected" : "";
    button.disabled = game.submitted;
  });
  submitButton.disabled = game.selectedIndex === null || game.submitted;
}
function showTurn() {
  stopTimer();
  game.selectedIndex = null;
  game.submitted = false;
  const question = currentQuestion();
  const player = currentPlayer();
  document.querySelector("#progress").textContent = `Turn ${game.turnIndex + 1} of ${game.questionQueue.length}. ${player.name}'s turn. Subject: ${question.subject}.`;
  document.querySelector("#question-heading").textContent = question.prompt;
  optionsBox.replaceChildren();
  question.options.forEach(function (option, index) {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "answer";
    const text = document.createElement("span");
    text.textContent = `${index + 1}. ${option}`;
    const marker = document.createElement("span");
    marker.className = "marker";
    button.append(text, marker);
    button.addEventListener("click", function () { selectAnswer(index); });
    optionsBox.append(button);
  });
  result.textContent = "";
  nextButton.hidden = true;
  deadline = Date.now() + game.secondsPerQuestion * 1000;
  renderSelection();
  showScreen("question-screen", "question-heading");
  timerId = setInterval(tick, 200);
  tick();
}
function selectAnswer(index) {
  if (game === null || game.phase !== "question" || game.submitted) return;
  if (Date.now() >= deadline) { finishTurn("timeout"); return; }
  if (!Number.isInteger(index) || index < 0 || index >= currentQuestion().options.length) return;
  game.selectedIndex = index;
  renderSelection();
}
function tick() {
  if (game === null || game.phase !== "question" || game.submitted) return;
  const remaining = Math.max(0, Math.ceil((deadline - Date.now()) / 1000));
  timeOutput.textContent = String(remaining);
  if (Date.now() >= deadline) finishTurn("timeout");
}
function finishTurn(reason) {
  if (game === null || game.phase !== "question" || game.submitted) return;
  game.submitted = true;
  stopTimer();
  const question = currentQuestion();
  const player = currentPlayer();
  const points = game.selectedIndex === question.correctIndex ? 10 : 0;
  const selectedText = game.selectedIndex === null ? "No answer" : question.options[game.selectedIndex];
  const correctText = question.options[question.correctIndex];
  player.score += points;
  // Snapshot fields make review independent of the later DOM.
  game.history.push({
    turn: game.turnIndex + 1, playerId: player.id, playerName: player.name,
    questionId: question.id, subject: question.subject, prompt: question.prompt,
    selectedIndex: game.selectedIndex, selectedText,
    correctIndex: question.correctIndex, correctText, points, reason
  });
  timeOutput.textContent = String(Math.max(0, Math.ceil((deadline - Date.now()) / 1000)));
  result.textContent = `${reason === "timeout" ? "Time ended. " : ""}${selectedText}. ${points} points. Correct answer: ${correctText}.`;
  renderSelection();
  nextButton.textContent = game.turnIndex + 1 === game.questionQueue.length ? "View results" : "Next turn";
  nextButton.hidden = false;
}
submitButton.addEventListener("click", function () {
  if (game === null || game.submitted) return;
  if (Date.now() >= deadline) { finishTurn("timeout"); return; }
  if (game.selectedIndex === null) return;
  finishTurn("manual");
});
nextButton.addEventListener("click", function () {
  if (game === null || game.phase !== "question" || !game.submitted) return;
  game.turnIndex += 1;
  if (game.turnIndex >= game.questionQueue.length) showResults();
  else showTurn();
});
function showResults() {
  stopTimer();
  game.phase = "results";
  const ranking = [...game.players].sort((a, b) => b.score - a.score);
  const body = document.querySelector("#ranking-body");
  body.replaceChildren();
  let previousScore = null;
  let rank = 0;
  ranking.forEach(function (player, index) {
    if (player.score !== previousScore) rank = index + 1;
    const row = document.createElement("tr");
    for (const value of [rank, player.name, player.score]) {
      const cell = document.createElement("td");
      cell.textContent = String(value);
      row.append(cell);
    }
    body.append(row);
    previousScore = player.score;
  });
  const winners = ranking.length === 0 ? [] : ranking.filter(p => p.score === ranking[0].score);
  document.querySelector("#winners").textContent = winners.length === 0 ? "No results." :
    `Winner${winners.length === 1 ? "" : "s"}: ${winners.map(p => p.name).join(", ")}. Top score: ${ranking[0].score}.`;
  const history = document.querySelector("#history");
  history.replaceChildren();
  game.history.forEach(function (record) {
    const item = document.createElement("li");
    item.className = "review-item";
    const heading = document.createElement("strong");
    heading.textContent = `${record.playerName}: ${record.prompt}`;
    const detail = document.createElement("p");
    detail.textContent = `Selected: ${record.selectedText}. Correct: ${record.correctText}. ${record.points} points. ${record.reason === "timeout" ? "Time ended." : "Submitted."}`;
    item.append(heading, detail);
    history.append(item);
  });
  document.querySelector("#json").textContent = JSON.stringify(game, null, 2);
  showScreen("results-screen", "results-heading");
}
function restartGame() {
  stopTimer();
  game = null;
  deadline = 0;
  setupFeedback.textContent = "";
  showScreen("setup-screen", "setup-heading");
}
document.querySelectorAll(".restart").forEach(button => button.addEventListener("click", restartGame));
setupForm.addEventListener("submit", startGame);
document.querySelector("#subject").addEventListener("change", updateAvailability);
updateAvailability();
