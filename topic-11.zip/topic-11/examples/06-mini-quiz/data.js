"use strict";
// Fixed records are interleaved by subject so Mixed starts with varied topics.
const QUESTIONS = [
  {
    "id": "q01",
    "subject": "HTML",
    "prompt": "Which element represents a paragraph?",
    "options": [
      "<p>",
      "<h1>",
      "<ul>",
      "<table>"
    ],
    "correctIndex": 0
  },
  {
    "id": "q02",
    "subject": "CSS",
    "prompt": "Which selector matches id=\"score\"?",
    "options": [
      ".score",
      "#score",
      "score",
      "*score"
    ],
    "correctIndex": 1
  },
  {
    "id": "q03",
    "subject": "JS",
    "prompt": "What does Number(\"3\") + 1 produce?",
    "options": [
      "\"31\"",
      "3",
      "4",
      "NaN"
    ],
    "correctIndex": 2
  },
  {
    "id": "q04",
    "subject": "HTML",
    "prompt": "Which attribute associates a label with an input?",
    "options": [
      "name",
      "for",
      "href",
      "src"
    ],
    "correctIndex": 1
  },
  {
    "id": "q05",
    "subject": "CSS",
    "prompt": "Which property controls text colour?",
    "options": [
      "background",
      "margin",
      "display",
      "color"
    ],
    "correctIndex": 3
  },
  {
    "id": "q06",
    "subject": "JS",
    "prompt": "What is the first array index?",
    "options": [
      "0",
      "1",
      "-1",
      "length"
    ],
    "correctIndex": 0
  },
  {
    "id": "q07",
    "subject": "HTML",
    "prompt": "Which button type avoids form submission?",
    "options": [
      "submit",
      "reset",
      "button",
      "send"
    ],
    "correctIndex": 2
  },
  {
    "id": "q08",
    "subject": "CSS",
    "prompt": "Which selector matches class=\"answer\"?",
    "options": [
      "#answer",
      "answer",
      ".answer",
      "@answer"
    ],
    "correctIndex": 2
  },
  {
    "id": "q09",
    "subject": "JS",
    "prompt": "Which value means no selected answer in our model?",
    "options": [
      "0",
      "false",
      "null",
      "\"0\""
    ],
    "correctIndex": 2
  },
  {
    "id": "q10",
    "subject": "HTML",
    "prompt": "Which element provides a form field label?",
    "options": [
      "<span>",
      "<label>",
      "<legend>",
      "<title>"
    ],
    "correctIndex": 1
  },
  {
    "id": "q11",
    "subject": "CSS",
    "prompt": "Which pseudo-class indicates keyboard-visible focus?",
    "options": [
      ":checked",
      ":visited",
      ":active",
      ":focus-visible"
    ],
    "correctIndex": 3
  },
  {
    "id": "q12",
    "subject": "JS",
    "prompt": "Which operator compares without type coercion?",
    "options": [
      "=",
      "==",
      "===",
      "=>"
    ],
    "correctIndex": 2
  },
  {
    "id": "q13",
    "subject": "HTML",
    "prompt": "Which attribute gives a unique element identifier?",
    "options": [
      "id",
      "class",
      "style",
      "title"
    ],
    "correctIndex": 0
  },
  {
    "id": "q14",
    "subject": "CSS",
    "prompt": "Which declaration creates a flex container?",
    "options": [
      "position: flex",
      "display: flex",
      "layout: flex",
      "float: flex"
    ],
    "correctIndex": 1
  },
  {
    "id": "q15",
    "subject": "JS",
    "prompt": "Which method keeps matching array entries?",
    "options": [
      "map",
      "push",
      "filter",
      "sort"
    ],
    "correctIndex": 2
  },
  {
    "id": "q16",
    "subject": "HTML",
    "prompt": "Which element holds an ordered list?",
    "options": [
      "<ul>",
      "<ol>",
      "<li>",
      "<dl>"
    ],
    "correctIndex": 1
  },
  {
    "id": "q17",
    "subject": "CSS",
    "prompt": "Which property adds space inside a border?",
    "options": [
      "gap",
      "outline",
      "margin",
      "padding"
    ],
    "correctIndex": 3
  },
  {
    "id": "q18",
    "subject": "JS",
    "prompt": "What does JSON.stringify return?",
    "options": [
      "A saved file",
      "A string",
      "A DOM node",
      "An interval"
    ],
    "correctIndex": 1
  },
  {
    "id": "q19",
    "subject": "HTML",
    "prompt": "Which attribute names an external script file?",
    "options": [
      "href",
      "for",
      "src",
      "action"
    ],
    "correctIndex": 2
  },
  {
    "id": "q20",
    "subject": "CSS",
    "prompt": "What does .answer.selected match?",
    "options": [
      "Any descendant",
      "An element with both classes",
      "Only IDs",
      "All selected options"
    ],
    "correctIndex": 1
  },
  {
    "id": "q21",
    "subject": "JS",
    "prompt": "With 3 players, what is 4 % 3?",
    "options": [
      "0",
      "1",
      "2",
      "3"
    ],
    "correctIndex": 1
  },
  {
    "id": "q22",
    "subject": "HTML",
    "prompt": "Which element represents a table row?",
    "options": [
      "<td>",
      "<th>",
      "<tr>",
      "<table-row>"
    ],
    "correctIndex": 2
  },
  {
    "id": "q23",
    "subject": "CSS",
    "prompt": "Which pseudo-class matches a pointer over an element?",
    "options": [
      ":focus-visible",
      ":hover",
      ":disabled",
      ":checked"
    ],
    "correctIndex": 1
  },
  {
    "id": "q24",
    "subject": "JS",
    "prompt": "Which method finds the first matching entry?",
    "options": [
      "filter",
      "map",
      "find",
      "forEach"
    ],
    "correctIndex": 2
  }
];
