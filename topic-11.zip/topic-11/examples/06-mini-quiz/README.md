# A cumulative mini quiz

Open index.html in a browser. Open study.html for the reading order, behaviour checks, extension, hint, solution explanation and complete source. No installation, server or internet connection is needed.

Previous knowledge: All form, CSS, DOM, event, selection and timer behaviours from examples 01–04.

New ideas: A question bank, arrays of player records, subject filtering, turn calculations, snapshot history and ranking.
