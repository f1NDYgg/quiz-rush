"use strict";
class Player {
  constructor(id, name, score = 0) {
    this.id = id;
    this.name = name;
    this.score = score;
  }
  addPoints(amount) {
    if (!Number.isInteger(amount) || amount < 0 || amount > 1000) return false;
    this.score += amount;
    return true;
  }
}
let nextId = 1;
let players = [];
const rows = document.querySelector("#ranking-body");
const picker = document.querySelector("#player");
const feedback = document.querySelector("#feedback");
function seedPlayers() {
  nextId = 1;
  players = [new Player(`p${nextId++}`, "Alex", 20),
  new Player(`p${nextId++}`, "Sam", 30), new Player(`p${nextId++}`, "Niki", 30)];
  feedback.textContent = "";
  render();
}
function render() {
  const previousId = picker.value;
  picker.replaceChildren();
  players.forEach(function (player) {
    const option = document.createElement("option");
    option.value = player.id;
    option.textContent = `${player.name} (${player.id})`;
    picker.append(option);
  });
  if (players.find(player => player.id === previousId)) picker.value = previousId;
  picker.disabled = players.length === 0;
  document.querySelector("#award").disabled = players.length === 0;
  document.querySelector("#roster").textContent = "Roster order: " +
    (players.map(player => `${player.name} (${player.id})`).join(", ") || "empty");
  const ranking = [...players].sort((a, b) => b.score - a.score);
  rows.replaceChildren();
  let previousScore = null;
  let rank = 0;
  ranking.forEach(function (player, index) {
    if (player.score !== previousScore) rank = index + 1;
    const row = document.createElement("tr");
    for (const value of [rank, player.name, player.score, player.id]) {
      const cell = document.createElement("td");
      cell.textContent = String(value);
      row.append(cell);
    }
    const actionCell = document.createElement("td");
    const removeButton = document.createElement("button");
    removeButton.type = "button";
    removeButton.dataset.id = player.id;
    removeButton.textContent = "Remove";
    removeButton.setAttribute("aria-label", `Remove ${player.name} (${player.id})`);
    actionCell.append(removeButton);
    row.append(actionCell);
    rows.append(row);
    previousScore = player.score;
  });
  const winners = ranking.length === 0 ? [] : ranking.filter(p => p.score === ranking[0].score);
  document.querySelector("#winners").textContent = winners.length === 0 ? "No players yet." :
    `Top score ${ranking[0].score}. Winner${winners.length === 1 ? "" : "s"}: ${winners.map(p => p.name).join(", ")}.`;
  document.querySelector("#json").textContent = JSON.stringify(players, null, 2);
}
document.querySelector("#add-form").addEventListener("submit", function (event) {
  event.preventDefault();
  const input = document.querySelector("#name");
  const name = input.value.trim();
  if (name.length < 1 || name.length > 30) {
    feedback.textContent = "Enter a name of 1–30 characters.";
    input.focus();
    return;
  }
  players.push(new Player(`p${nextId++}`, name));
  input.value = "";
  feedback.textContent = `${name} added as a new record.`;
  render();
  input.focus();
});
document.querySelector("#award-form").addEventListener("submit", function (event) {
  event.preventDefault();
  const player = players.find(p => p.id === picker.value);
  const amountInput = document.querySelector("#amount");
  const raw = amountInput.value.trim();
  const amount = Number(raw);
  if (player === undefined) { feedback.textContent = "Choose an existing player."; return; }
  if (raw === "" || !player.addPoints(amount)) {
    feedback.textContent = "Enter whole points from 0 to 1000.";
    amountInput.focus();
    return;
  }
  feedback.textContent = `${amount} points added to ${player.name} (${player.id}).`;
  render();
});
// Delegation stays on the existing tbody while rows are rebuilt.
rows.addEventListener("click", function (event) {
  const button = event.target.closest("button[data-id]");
  if (button === null || !rows.contains(button)) return;
  players = players.filter(player => player.id !== button.dataset.id);
  feedback.textContent = `Removed ${button.dataset.id}.`;
  render();
  document.querySelector("#name").focus();
});
document.querySelector("#reset").addEventListener("click", seedPlayers);
seedPlayers();
