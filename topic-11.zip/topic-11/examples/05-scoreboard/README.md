# A player scoreboard

Open index.html in a browser. Open study.html for the reading order, behaviour checks, extension, hint, solution explanation and complete source. No installation, server or internet connection is needed.

Previous knowledge: Forms, validation, DOM creation, event delegation and state rendering.

New ideas: A Player class, arrays of records, stable IDs, find, filter, map, copied sorting, ties and JSON.
