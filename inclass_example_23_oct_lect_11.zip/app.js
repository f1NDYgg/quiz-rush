const data = [
    {
        title: "1. Personal Info",
        subTitle: "Tell us a bit about yourself",
        headerText: "Basic information",
        icon: "person",
        secitons: [
            {
                fields: [
                    {
                        icon: "person",
                        type: "input",
                        title: "Full Name",
                        name: "fullName",
                        required: true,

                    },
                    {
                        icon: "mail",
                        type: "input",
                        title: "Email",
                        name: "Email",
                        required: true,
                    }
                ]
            },
            {
                fields: [
                    {
                        icon: "phone",
                        type: "input",
                        title: "Phone",
                        name: "fullName",
                        required: true
                    },
                    {
                        icon: "globe",
                        type: "select",
                        title: "Country",
                        name: "fullName",
                        required: true,
                        values: [
                            'Bulgaria',
                            'Other',
                            '...'
                        ],
                    },
                ]

            }
        ],

        step: 1
    },
    {
        title: "2. Preferences",
        subTitle: "Let us know your preferences and interests",
        headerText: "Your selections",
        icon: "settings",
        secitons: [
            {
                fields: [
                    {
                        type: "radio",
                        title: 'Contact Method',
                        name: "contactMethod",
                        values: [
                            "Email",
                            "Phone",
                            "WhatsApp"
                        ]

                    },
                ]
            },
            {
                fields: [
                    {

                        type: "checkbox",
                        title: 'Interested In',
                        name: "interestedIn",
                        values: [
                            "Web Design",
                            "SEO",
                            "E-commerce",
                            "Other"
                        ],
                        otherField: true
                    }
                ]
            },

        ],
        step: 2
    },

    {
        title: "3. Aditional Details",
        subTitle: "Provide more information about your project.",
        headerText: "Project information",
        icon: "note",
        secitons: [
            {
                fields: [
                    {
                        type: "textarea",
                        title: "Project Description",
                        name: "profectDescription",
                    },
                    {
                        type: "textarea",
                        title: "Aditional Notes",
                        name: "notes",
                    }
                ]
            },

        ],
        step: 3
    }
];

const states = {
    state: 1
};



function render(step) {
    let html = '';
    data.forEach((section, index) => {

        //console.log(index);
        //console.log(section.title);
        //console.log(section.step);
        if (index + 1 == step) {
            html = `<section class="block-form">
        <div class="title_holder">
            <div class="icon icon-${section.icon}"></div>
            <div class="title_text_holder">
                <h2>${section.title}</h2>
                <p>${section.subTitle}</p>
            </div>
        </div>
        <div class="form_section">
        `;
            section.secitons.forEach((group) => {
                html = html + `<div class="section_forms">`;

                group.fields.forEach((field) => {
                    //console.log(field.type);
                    //console.log(field.name);
                    html = html + renderByType(field);
                });

                html = html + `</div>`
            });

            html = html + `</div>
            <div class="button_hoder">
                <button type="button" onclick="decreeseState()" class="button_prev"> <- Previous </button>
                <button type="button" onclick="increaseState()" class="button_next"> Next -> </button>
            </div>
            </section>`;
        }
    });

    //console.log(html);

    document.querySelector('#form').innerHTML = html;

}

function renderByType(field) {
    if (field.type == "input") {
        let requiredSymbol = '';
        if (field.required) {
            requiredSymbol = '<span class="required_symbol">*</span>';
        }
        return `
        <label>
        ${field.title}${requiredSymbol}<br>
            <input type="text" name="${field.name}" />
        </label>`;
    }
    else if (field.type == "select") {
        let requiredSymbol = '';
        if (field.required) {
            requiredSymbol = '<span class="required_symbol">*</span>';
        }
        //console.log('test', field.values);
        let outHTML = `
        <label>
        ${field.title}${requiredSymbol}<br>
            <select name="${field.name}">`
        field.values.forEach((value) => {
            outHTML += `<option>${value}</option>`;
        });
        outHTML += `</select>
        </label>`;
        return outHTML;
    } else if (field.type == "radio") {
        console.log(field);
        let requiredSymbol = '';
        if (field.required) {
            requiredSymbol = '<span class="required_symbol">*</span>';
        }
        let outHTML = `<div>${field.title}${requiredSymbol}<br>`;
        field.values.forEach((value) => {
            outHTML += `<label><input type="radio" name="${field.name}" value=${value} />${value}</label>`;
        });
        outHTML += `</div>`;
        return outHTML;
    }
    else if (field.type == "checkbox") {
        let requiredSymbol = '';
        if (field.required) {
            requiredSymbol = '<span class="required_symbol">*</span>';
        }
        let outHTML = `<div>${field.title}${requiredSymbol}<br>`;
        field.values.forEach((value) => {
            outHTML += `<label><input type="checkbox" name="${field.name}[]" value=${value} />${value}</label>`;
        });
        outHTML += `</div>`;
        if (field.otherField) {
            outHTML += `<label>Please specify${requiredSymbol}<br>
            <textarea name="preferences[other]"></textarea>`
        }
        return outHTML;
    } else if (field.type == "textarea") {
        let requiredSymbol = '';
        if (field.required) {
            requiredSymbol = '<span class="required_symbol">*</span>';
        }
        return `<label>
           ${field.title}${requiredSymbol}<br>
            <textarea name="${field.name}"></textarea>
        </label>`;
    }
}

function renderTitlePart(step) {
    let html = '';
    data.forEach((section, index) => {

        // //console.log(index);
        // //console.log(section.title);
        // //console.log(section.step);
        let activeState = '';
        if (index + 1 == step) {
            activeState = ' active';
        }
        html += `<section class="block-form${activeState}">
        <div class="title_holder">
            <div class="number">${index + 1}</div>
            <div class="title_text_holder">
                <h2>${section.title}</h2>
                <p>${section.headerText}</p>
            </div>
        </div>
        </section>
        `;
    });

    html += `<section class="block-form">
        <div class="title_holder">
            <div class="number">4</div>
            <div class="title_text_holder">
                <h2>4. Review</h2>
                <p>Confirm & submit</p>
            </div>
        </div>
        </section>`;

    // //console.log(html);

    document.querySelector('#states').innerHTML = html;

}

function increaseState() {
    if (states.state > 3) {
        //go to submit;
        return;
    }
    renderTitlePart(states.state + 1);
    render(states.state + 1);
    states.state = states.state + 1;
}

function decreeseState() {
    if (states.state == 1) {
        return;
    }
    renderTitlePart(states.state - 1);
    render(states.state - 1);
    states.state = states.state - 1;
    // console.log(states)
}

renderTitlePart(states.state);
render(states.state);
