const data = [
    {
        title: "1. Personal Info",
        subTitle: "Tell us a bit about yourself",
        headerText: "Basic information",
        icon: "person",
        secitons: [
            {
                fields: [
                    {
                        icon: "person",
                        type: "text",
                        title: "Full Name",
                        name: "fullName",
                        required: true,

                    },
                    {
                        icon: "mail",
                        type: "email",
                        title: "Email",
                        name: "email",
                        required: true,
                    }
                ]
            },
            {
                fields: [
                    {
                        icon: "phone",
                        type: "phone",
                        title: "Phone",
                        name: "phone",
                        required: true
                    },
                    {
                        icon: "globe",
                        type: "select",
                        title: "Country",
                        name: "countryName",
                        required: true,
                        values: [
                            'Bulgaria',
                            'Other',
                            '...'
                        ],
                    },
                ]

            }
        ],

        step: 1
    },
    {
        title: "2. Preferences",
        subTitle: "Let us know your preferences and interests",
        headerText: "Your selections",
        icon: "settings",
        secitons: [
            {
                fields: [
                    {
                        type: "radio",
                        title: 'Contact Method',
                        name: "contactMethod",
                        values: [
                            "Email",
                            "Phone",
                            "WhatsApp"
                        ]

                    },
                ]
            },
            {
                fields: [
                    {

                        type: "checkbox",
                        title: 'Interested In',
                        name: "interestedIn",
                        values: [
                            "Web Design",
                            "SEO",
                            "E-commerce",
                            "Other"
                        ],
                        otherField: true
                    }
                ]
            },

        ],
        step: 2
    },

    {
        title: "3. Aditional Details",
        subTitle: "Provide more information about your project.",
        headerText: "Project information",
        icon: "note",
        secitons: [
            {
                fields: [
                    {
                        type: "textarea",
                        title: "Project Description",
                        name: "profectDescription",
                    },
                    {
                        type: "textarea",
                        title: "Aditional Notes",
                        name: "notes",
                    }
                ]
            },

        ],
        step: 3
    }
];

const submitData = {
    fullName: "",
    email: "",
    phone: "",
    countryName: "",
    contactMethod: "",
    interestedIn: [],
    interestedInExtra: "",
    profectDescription: "",
    notes: ""
};

const states = {
    state: 1
};

function render(step) {

    let html = '';

    data.forEach((section, index) => {
        // console.log(index,'1');
        // console.log(section,'2');
        // console.log(section.headerText,'new add');
        // console.log(section.step,'3');

        if (index + 1 == step) {

            html = `<section class="block-form">
        <div class="title_holder">
            <div class="icon icon-${section.icon}"></div>
            <div class="title_text_holder">
                <h2>${section.title}</h2>
                <p>${section.subTitle}</p>
            </div>
        </div>
        <div class="form_section">
        `;
            section.secitons.forEach((group) => {
                html = html + `<div class="section_forms">`;
                // console.log('section');
                group.fields.forEach((field) => {
                    // console.log(field, '1');
                    // console.log(field.name,'2');
                    html = html + renderByType(field);
                });

                html = html + `</div>`;
            });

            html = html + `</div>
            <div class="button_hoder">`;
            let isDisabled = '';
            if (step == 1) {
                isDisabled = 'disabled';
            }
            html += `<button type="button" id="decreeseState" class="button_prev" ${isDisabled}> <- Previous </button>`;

            isDisabled = '';
            if (step == 3) {
                isDisabled = 'disabled';
            }
            html += `<button type="button" id="increaseState" class="button_next" ${isDisabled}> Next -> </button>
            </div>
            </section>`;
        }
    });

    //console.log(html);

    document.querySelector('#form').innerHTML = html;

    document.querySelector('#increaseState').addEventListener('click', increaseState);
    document.querySelector('#decreeseState').addEventListener('click', decreeseState);

    printSubmitData();
}

function renderByType(field) {
    let requiredSymbol = '';
    let outHTML = '';

    switch (field.type) {
        case "text":
        case "email":
        case "phone":

            if (field.required) {
                requiredSymbol = '<span class="required_symbol">*</span>';
            }
            return `<label>
                ${field.title}${requiredSymbol}<br>
                    <input type="${field.type}" name="${field.name}" value="${submitData[field.name]}" />
                </label>`;
            break;

        case "select":

            if (field.required) {
                requiredSymbol = '<span class="required_symbol">*</span>';
            }
            //console.log('test', field.values);
            outHTML = `
        <label>
        ${field.title}${requiredSymbol}<br>
            <select name="${field.name}"><option></option>`
            field.values.forEach((value) => {
                if (submitData[field.name] == value) {
                    outHTML += `<option selected>${value}</option>`;
                } else {
                    outHTML += `<option>${value}</option>`;
                }
            });
            outHTML += `</select>
        </label>`;
            return outHTML;
            break;
        case "radio":

            console.log(field);
            if (field.required) {
                requiredSymbol = '<span class="required_symbol">*</span>';
            }
            outHTML = `<div>${field.title}${requiredSymbol}<br>`;
            field.values.forEach((value) => {
                let isChecked = submitData[field.name] == value ? 'checked' : '';

                outHTML += `<label><input type="radio" name="${field.name}" value=${value} ${isChecked} />${value}</label>`;
            });
            outHTML += `</div>`;
            return outHTML;

            break;

        case "checkbox":

            if (field.required) {
                requiredSymbol = '<span class="required_symbol">*</span>';
            }
            outHTML = `<div>${field.title}${requiredSymbol}<br>`;
            field.values.forEach((value) => {
                let isChecked = '';
                if (submitData[field.name].indexOf(value) > -1) {
                    isChecked = 'checked';
                }
                // let isChecked = submitData[field.name].inArray(value) ? 'checked' : '';
                outHTML += `<label><input type="checkbox" name="${field.name}" value=${value} ${isChecked} />${value}</label>`;
            });
            outHTML += `</div>`;
            if (field.otherField) {
                outHTML += `<label>Please specify${requiredSymbol}<br>
            <textarea name="preferences[other]"></textarea>`
            }
            return outHTML;
            break;

        case "textarea":
            if (field.required) {
                requiredSymbol = '<span class="required_symbol">*</span>';
            }
            return `<label>${field.title}${requiredSymbol}<br>
            <textarea name="${field.name}"></textarea>
        </label>`;
            break;

        default:
            //default must have
            break;
    }
}

function renderTitlePart(step) {
    let html = '';
    data.forEach((section, index) => {

        // //console.log(index);
        // //console.log(section.title);
        // //console.log(section.step);
        let activeState = '';
        if (index + 1 == step) {
            activeState = ' active';
        }
        html += `<section class="block-form${activeState}">
        <div class="title_holder">
            <div class="number">${index + 1}</div>
            <div class="title_text_holder">
                <h2>${section.title}</h2>
                <p>${section.headerText}</p>
            </div>
        </div>
        </section>
        `;
    });

    html += `<section class="block-form">
        <div class="title_holder">
            <div class="number">4</div>
            <div class="title_text_holder">
                <h2>4. Review</h2>
                <p>Confirm & submit</p>
            </div>
        </div>
        </section>`;

    // //console.log(html);

    document.querySelector('#states').innerHTML = html;


    // document.querySelector('#decreeseState').addEventListener('click', decreeseState());
    // document.querySelector('#increaseState').addEventListener('click', increaseState());
}

function increaseState() {
    if (states.state > 3) {
        //go to submit;
        return;
    }
    renderTitlePart(states.state + 1);
    render(states.state + 1);
    states.state = states.state + 1;
}

function decreeseState() {
    if (states.state == 1) {
        return;
    }
    renderTitlePart(states.state - 1);
    render(states.state - 1);
    states.state = states.state - 1;
    // console.log(states)
}

renderTitlePart(states.state);
render(states.state);

document.querySelector('#form').addEventListener('input', (event) => {
    // console.log(submitData[event.target.name],event.target.name,event.target.value)
    if (Array.isArray(submitData[event.target.name])) {
        // submitData[event.target.name]
        // console.log(event.target.value,submitData[event.target.name].indexOf(event.target.value));
        if (submitData[event.target.name].indexOf(event.target.value) == -1) {
            submitData[event.target.name].push(event.target.value);
            // console.log(submitData);
        }
    } else {
        submitData[event.target.name] = event.target.value;
    }
});


function printSubmitData() {
    console.log(submitData);
}
